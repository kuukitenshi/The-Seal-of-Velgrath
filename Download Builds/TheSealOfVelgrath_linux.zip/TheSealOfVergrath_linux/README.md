# The Seal of Vergrath - Prototype

Welcome to the prototype of The Seal of Vergrath!

## How to Run the Game
To play the game, follow these steps:

1. Make sure you are using the Linux operating system.
2. Right-click on the ``Linux.x86_64`` file.
3. Garant permission to execute running the command:
    ```
    chmod +x Linux.x86_64
    ```
4. You can double-click the ```Linux.x86_64``` file to run the game, or run it from the terminal using the command:
    ```
    ./Linux.x86_64
    ```

## Development Team
This prototype was developed by:

- João Pereira - 112175
- Laura Cunha - 112269
- Rodrigo Correia - 112270
- Martim Pereira - 112272