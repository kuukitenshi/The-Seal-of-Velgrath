# The Seal of Vergrath - Prototype

Welcome to the prototype of The Seal of Vergrath!

## How to Run the Game
To play the game, follow these steps:

1. Make sure you are using the Windows operating system.
2. Double-click the ``DDJ.exe`` executable file to start the game.


## Development Team
This prototype was developed by:

- João Pereira - 112175
- Laura Cunha - 112269
- Rodrigo Correia - 112270
- Martim Pereira - 112272